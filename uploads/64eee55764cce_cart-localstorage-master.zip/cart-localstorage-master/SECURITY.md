# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| All     | :white_check_mark: |


## Reporting a Vulnerability

Vulnerability issues should be reported directly on the peet86/cart-localstorage repository via github issues. 
Expected response time: 72h
